/*
# Create contact_requests table (single-tenant, no auth)

1. New Tables
- `contact_requests`
  - `id` (uuid, primary key)
  - `name` (text, not null) — имя клиента
  - `phone` (text, not null) — телефон клиента
  - `email` (text, nullable) — email клиента
  - `message` (text, nullable) — сообщение/комментарий
  - `created_at` (timestamptz, default now())

2. Security
- Enable RLS on `contact_requests`.
- Grant INSERT to `anon` + `authenticated` so the contact form (no login) can submit.
- Allow anon + authenticated INSERT because the form is intentionally public.
- No SELECT/UPDATE/DELETE policies — only agency staff with service_role can read submissions.
*/

CREATE TABLE IF NOT EXISTS contact_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  phone text NOT NULL,
  email text,
  message text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE contact_requests ENABLE ROW LEVEL SECURITY;

GRANT INSERT ON contact_requests TO anon, authenticated;
GRANT SELECT, UPDATE, DELETE ON contact_requests TO service_role;

DROP POLICY IF EXISTS "anon_insert_contact_requests" ON contact_requests;
CREATE POLICY "anon_insert_contact_requests" ON contact_requests
FOR INSERT TO anon, authenticated WITH CHECK (true);
