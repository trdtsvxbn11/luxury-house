import { Crown } from 'lucide-react';

export function Footer() {
  return (
    <footer className="relative border-t border-gold-500/15 bg-dark-950 py-16">
      <div className="mx-auto max-w-7xl px-6 md:px-10">
        <div className="flex flex-col items-center gap-8 text-center">
          <div className="flex items-center gap-3">
            <Crown className="h-6 w-6 text-gold-400" />
            <span className="font-serif text-2xl font-semibold tracking-wide text-cream-100">
              Prime
            </span>
            <span className="text-xs uppercase tracking-[0.3em] text-gold-400">Estate</span>
          </div>

          <div className="luxury-line max-w-xs w-full" />

          <p className="max-w-md text-sm font-light leading-relaxed text-cream-200/40">
            Агентство премиальной недвижимости Prime. Эксклюзивные объекты
            для требовательных клиентов.
          </p>

          <div className="flex flex-col gap-2 text-sm font-light text-cream-200/50 sm:flex-row sm:gap-8">
            <a href="tel:+74951234567" className="transition-colors hover:text-gold-400">+7 (495) 123-45-67</a>
            <a href="mailto:info@prime-estate.ru" className="transition-colors hover:text-gold-400">info@prime-estate.ru</a>
            <span>Москва, ул. Тверская, 1</span>
          </div>

          <div className="mt-4 text-xs font-light text-cream-300/30">
            © 2026 Prime Estate. Все права защищены.
          </div>
        </div>
      </div>
    </footer>
  );
}
