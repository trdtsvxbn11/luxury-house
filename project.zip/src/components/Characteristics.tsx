import { useScrollReveal } from '@/hooks/useScrollReveal';

const specs = [
  { label: 'Площадь дома', value: '280 кв.м.' },
  { label: 'Площадь участка', value: '8 соток' },
  { label: 'Этажность', value: '3 этажа' },
  { label: 'Количество комнат', value: '5' },
  { label: 'Спальни', value: '4 (2 этаж)' },
  { label: 'Гостиная + кухня', value: '1 этаж' },
  { label: 'Материал стен', value: 'Кирпич' },
  { label: 'Тип ремонта', value: 'Дизайнерский под ключ' },
  { label: 'Остекление', value: 'Панорамные окна' },
  { label: 'Посёлок', value: 'Закрытый, охраняемый' },
  { label: 'Локация', value: '2 км от МКАД' },
  { label: 'Шоссе', value: 'Алтуфьевское' },
];

export function Characteristics() {
  const { ref, visible } = useScrollReveal<HTMLDivElement>();

  return (
    <section id="characteristics" className="relative bg-dark-950 py-24 md:py-32">
      <div className="mx-auto max-w-7xl px-6 md:px-10">
        {/* Section header */}
        <div ref={ref} className={`reveal ${visible ? 'reveal-visible' : ''} mb-16 text-center`}>
          <div className="mb-6 flex items-center justify-center gap-4">
            <span className="luxury-line w-12" />
            <span className="text-xs font-medium uppercase tracking-[0.4em] text-gold-400">
              Характеристики
            </span>
            <span className="luxury-line w-12" />
          </div>
          <h2 className="font-serif text-4xl font-light text-cream-50 md:text-5xl">
            Параметры <span className="gold-text font-medium">особняка</span>
          </h2>
          <p className="mx-auto mt-6 max-w-2xl text-base font-light leading-relaxed text-cream-200/60">
            Каждый параметр дома продуман для безупречного комфорта и безопасности
            его будущих владельцев.
          </p>
        </div>

        {/* Specs grid */}
        <div className="grid grid-cols-1 gap-px overflow-hidden rounded-sm border border-gold-500/15 bg-gold-500/15 sm:grid-cols-2 lg:grid-cols-3">
          {specs.map((spec, i) => (
            <div
              key={spec.label}
              className={`group relative bg-dark-900 p-8 transition-all duration-500 hover:bg-dark-800 ${
                visible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
              }`}
              style={{
                transition: 'opacity 0.6s ease, transform 0.6s ease',
                transitionDelay: `${0.1 + i * 0.05}s`,
              }}
            >
              <div className="mb-2 text-xs uppercase tracking-[0.2em] text-cream-300/40">
                {spec.label}
              </div>
              <div className="font-serif text-2xl font-light text-cream-50 transition-colors duration-300 group-hover:text-gold-400">
                {spec.value}
              </div>
              <div className="absolute bottom-0 left-0 h-px w-0 bg-gradient-to-r from-gold-500 to-gold-400 transition-all duration-500 group-hover:w-full" />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
