import { useState } from 'react';
import { X, ChevronLeft, ChevronRight } from 'lucide-react';
import { useScrollReveal } from '@/hooks/useScrollReveal';

const galleryImages: { src: string; title: string; span: string }[] = [
  {
    src: 'https://picsum.photos/id/101/1200/800',
    title: 'Фасад особняка',
    span: 'lg:col-span-2 lg:row-span-2',
  },
  {
    src: 'https://picsum.photos/id/17/800/600',
    title: 'Гостиная',
    span: '',
  },
  {
    src: 'https://picsum.photos/id/106/800/600',
    title: 'Кухня',
    span: '',
  },
  {
    src: 'https://picsum.photos/id/104/800/600',
    title: 'Спальня',
    span: '',
  },
  {
    src: 'https://picsum.photos/id/100/800/600',
    title: 'Ванная комната',
    span: '',
  },
  {
    src: 'https://picsum.photos/id/12/1200/600',
    title: 'Дом вечером',
    span: 'lg:col-span-2',
  },
  {
    src: 'https://picsum.photos/id/15/800/600',
    title: 'Вид снаружи',
    span: '',
  },
  {
    src: 'https://picsum.photos/id/103/800/600',
    title: 'Кухня-столовая',
    span: '',
  },
];

export function Gallery() {
  const { ref, visible } = useScrollReveal<HTMLDivElement>();
  const [lightbox, setLightbox] = useState<number | null>(null);

  const openLightbox = (index: number) => setLightbox(index);
  const closeLightbox = () => setLightbox(null);
  const prevImage = () =>
    setLightbox((prev) => (prev === null ? null : (prev - 1 + galleryImages.length) % galleryImages.length));
  const nextImage = () =>
    setLightbox((prev) => (prev === null ? null : (prev + 1) % galleryImages.length));

  return (
    <section id="gallery" className="relative bg-dark-950 py-24 md:py-32">
      <div className="mx-auto max-w-7xl px-6 md:px-10">
        <div ref={ref} className={`reveal ${visible ? 'reveal-visible' : ''} mb-16 text-center`}>
          <div className="mb-6 flex items-center justify-center gap-4">
            <span className="luxury-line w-12" />
            <span className="text-xs font-medium uppercase tracking-[0.4em] text-gold-400">
              Галерея
            </span>
            <span className="luxury-line w-12" />
          </div>
          <h2 className="font-serif text-4xl font-light text-cream-50 md:text-5xl">
            Фотогалерея <span className="gold-text font-medium">дома</span>
          </h2>
          <p className="mx-auto mt-6 max-w-2xl text-base font-light leading-relaxed text-cream-200/60">
            Визуальное путешествие по пространству, где каждая комната —
            произведение дизайнерского искусства.
          </p>
        </div>

        {/* Gallery grid */}
        <div className="grid auto-rows-[220px] grid-cols-2 gap-4 lg:grid-cols-4">
          {galleryImages.map((img, i) => (
            <div
              key={i}
              className={`gallery-img group relative cursor-pointer overflow-hidden rounded-sm border border-gold-500/10 ${img.span}`}
              onClick={() => openLightbox(i)}
            >
              <img src={img.src} alt={img.title} loading="lazy" className="h-full w-full object-cover" />
              <div className="absolute inset-0 bg-gradient-to-t from-dark-950/90 via-transparent to-transparent opacity-0 transition-opacity duration-500 group-hover:opacity-100" />
              <div className="absolute bottom-0 left-0 translate-y-4 p-5 opacity-0 transition-all duration-500 group-hover:translate-y-0 group-hover:opacity-100">
                <span className="text-sm font-light text-cream-100">{img.title}</span>
              </div>
              <div className="absolute inset-0 border border-gold-400/0 transition-all duration-500 group-hover:inset-2 group-hover:border-gold-400/30" />
            </div>
          ))}
        </div>
      </div>

      {/* Lightbox */}
      {lightbox !== null && (
        <div
          className="fixed inset-0 z-[100] flex items-center justify-center bg-dark-950/95 backdrop-blur-md"
          onClick={closeLightbox}
        >
          <button
            className="absolute right-6 top-6 z-10 text-cream-200/60 transition-colors hover:text-gold-400"
            onClick={closeLightbox}
          >
            <X className="h-8 w-8" />
          </button>
          <button
            className="absolute left-6 z-10 text-cream-200/60 transition-colors hover:text-gold-400"
            onClick={(e) => { e.stopPropagation(); prevImage(); }}
          >
            <ChevronLeft className="h-10 w-10" />
          </button>
          <img
            src={galleryImages[lightbox].src}
            alt={galleryImages[lightbox].title}
            className="max-h-[85vh] max-w-[90vw] rounded-sm object-contain"
            onClick={(e) => e.stopPropagation()}
          />
          <button
            className="absolute right-6 z-10 text-cream-200/60 transition-colors hover:text-gold-400"
            onClick={(e) => { e.stopPropagation(); nextImage(); }}
          >
            <ChevronRight className="h-10 w-10" />
          </button>
          <div className="absolute bottom-10 left-1/2 -translate-x-1/2 text-center">
            <span className="font-serif text-xl font-light text-cream-100">
              {galleryImages[lightbox].title}
            </span>
            <div className="mt-2 text-xs uppercase tracking-[0.3em] text-gold-400">
              {lightbox + 1} / {galleryImages.length}
            </div>
          </div>
        </div>
      )}
    </section>
  );
}
