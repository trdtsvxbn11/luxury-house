import { useState, type FormEvent } from 'react';
import { Send, CheckCircle2, Loader2, Phone, Mail, User, MessageSquare } from 'lucide-react';
import { useScrollReveal } from '@/hooks/useScrollReveal';
import { supabase } from '@/lib/supabase';

type FormState = 'idle' | 'loading' | 'success' | 'error';

export function ContactForm() {
  const { ref, visible } = useScrollReveal<HTMLDivElement>();
  const [formState, setFormState] = useState<FormState>('idle');
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    email: '',
    message: '',
  });

  const handleChange = (field: keyof typeof formData, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!formData.name.trim() || !formData.phone.trim()) return;

    setFormState('loading');

    try {
      const { error } = await supabase.from('contact_requests').insert({
        name: formData.name.trim(),
        phone: formData.phone.trim(),
        email: formData.email.trim() || null,
        message: formData.message.trim() || null,
      });

      if (error) throw error;

      setFormState('success');
      setFormData({ name: '', phone: '', email: '', message: '' });
      setTimeout(() => setFormState('idle'), 6000);
    } catch {
      setFormState('error');
      setTimeout(() => setFormState('idle'), 6000);
    }
  };

  return (
    <section id="contact" className="relative bg-dark-900 py-24 md:py-32">
      <div className="mx-auto max-w-5xl px-6 md:px-10">
        <div ref={ref} className={`reveal ${visible ? 'reveal-visible' : ''} mb-16 text-center`}>
          <div className="mb-6 flex items-center justify-center gap-4">
            <span className="luxury-line w-12" />
            <span className="text-xs font-medium uppercase tracking-[0.4em] text-gold-400">
              Контакты
            </span>
            <span className="luxury-line w-12" />
          </div>
          <h2 className="font-serif text-4xl font-light text-cream-50 md:text-5xl">
            Запишитесь на
            <span className="gold-text font-medium"> просмотр</span>
          </h2>
          <p className="mx-auto mt-6 max-w-2xl text-base font-light leading-relaxed text-cream-200/60">
            Оставьте заявку, и персональный брокер агентства Prime свяжется с
            вами в течение 30 минут, чтобы согласовать удобное время посещения.
          </p>
        </div>

        {/* Form card */}
        <div className={`scale-reveal ${visible ? 'scale-reveal-visible' : ''} relative overflow-hidden rounded-sm border border-gold-500/20 bg-dark-800/50 p-8 md:p-12`}>
          {/* Decorative corners */}
          <div className="absolute left-0 top-0 h-16 w-16 border-l border-t border-gold-500/30" />
          <div className="absolute bottom-0 right-0 h-16 w-16 border-b border-r border-gold-500/30" />

          {formState === 'success' ? (
            <div className="flex flex-col items-center justify-center py-16 text-center">
              <CheckCircle2 className="mb-6 h-16 w-16 text-gold-400" />
              <h3 className="mb-3 font-serif text-3xl font-light text-cream-50">
                Заявка отправлена
              </h3>
              <p className="max-w-md text-base font-light text-cream-200/60">
                Благодарим за интерес. Брокер агентства Prime свяжется с вами
                в ближайшее время.
              </p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-8">
              <div className="grid grid-cols-1 gap-8 md:grid-cols-2">
                {/* Name */}
                <div className="relative">
                  <label className="mb-3 flex items-center gap-2 text-xs uppercase tracking-[0.2em] text-cream-300/50">
                    <User className="h-3.5 w-3.5 text-gold-400" />
                    Имя *
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.name}
                    onChange={(e) => handleChange('name', e.target.value)}
                    placeholder="Иван Иванов"
                    className="luxury-input w-full rounded-sm px-5 py-4 text-base"
                  />
                </div>

                {/* Phone */}
                <div className="relative">
                  <label className="mb-3 flex items-center gap-2 text-xs uppercase tracking-[0.2em] text-cream-300/50">
                    <Phone className="h-3.5 w-3.5 text-gold-400" />
                    Телефон *
                  </label>
                  <input
                    type="tel"
                    required
                    value={formData.phone}
                    onChange={(e) => handleChange('phone', e.target.value)}
                    placeholder="+7 (999) 123-45-67"
                    className="luxury-input w-full rounded-sm px-5 py-4 text-base"
                  />
                </div>
              </div>

              {/* Email */}
              <div className="relative">
                <label className="mb-3 flex items-center gap-2 text-xs uppercase tracking-[0.2em] text-cream-300/50">
                  <Mail className="h-3.5 w-3.5 text-gold-400" />
                  Email
                </label>
                <input
                  type="email"
                  value={formData.email}
                  onChange={(e) => handleChange('email', e.target.value)}
                  placeholder="ivan@example.com"
                  className="luxury-input w-full rounded-sm px-5 py-4 text-base"
                />
              </div>

              {/* Message */}
              <div className="relative">
                <label className="mb-3 flex items-center gap-2 text-xs uppercase tracking-[0.2em] text-cream-300/50">
                  <MessageSquare className="h-3.5 w-3.5 text-gold-400" />
                  Сообщение
                </label>
                <textarea
                  rows={4}
                  value={formData.message}
                  onChange={(e) => handleChange('message', e.target.value)}
                  placeholder="Удобное время для звонка, вопросы о доме..."
                  className="luxury-input w-full resize-none rounded-sm px-5 py-4 text-base"
                />
              </div>

              {/* Error message */}
              {formState === 'error' && (
                <p className="text-sm font-light text-red-400">
                  Не удалось отправить заявку. Пожалуйста, попробуйте ещё раз или позвоните нам.
                </p>
              )}

              {/* Submit */}
              <div className="flex flex-col items-center gap-4 pt-4">
                <button
                  type="submit"
                  disabled={formState === 'loading'}
                  className="group relative flex items-center gap-3 overflow-hidden rounded-sm bg-gradient-to-r from-gold-600 to-gold-500 px-10 py-4 text-sm font-medium uppercase tracking-widest text-dark-950 transition-all duration-300 hover:from-gold-500 hover:to-gold-400 disabled:opacity-60"
                >
                  {formState === 'loading' ? (
                    <>
                      <Loader2 className="h-5 w-5 animate-spin" />
                      Отправка...
                    </>
                  ) : (
                    <>
                      Отправить заявку
                      <Send className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1" />
                    </>
                  )}
                </button>
                <p className="text-xs font-light text-cream-300/40">
                  Нажимая кнопку, вы соглашаетесь с политикой конфиденциальности
                </p>
              </div>
            </form>
          )}
        </div>
      </div>
    </section>
  );
}
