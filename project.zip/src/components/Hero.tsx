import { useEffect, useState } from 'react';
import { MapPin, ArrowDown, Shield, Building2 } from 'lucide-react';

export function Hero() {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 80);
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  return (
    <section className="relative min-h-screen w-full overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 z-0">
        <img
          src="https://picsum.photos/id/101/1920/1080"
          alt="Премиальный особняк"
          className="h-full w-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-dark-950/80 via-dark-950/50 to-dark-950" />
        <div className="absolute inset-0 bg-gradient-to-r from-dark-950/70 to-transparent" />
      </div>

      {/* Content */}
      <div className="relative z-10 flex min-h-screen flex-col">
        {/* Top bar */}
        <div className={`fixed left-0 right-0 top-0 z-50 transition-all duration-500 ${scrolled ? 'bg-dark-950/90 backdrop-blur-md py-4' : 'py-7'}`}>
          <div className="mx-auto flex max-w-7xl items-center justify-between px-6 md:px-10">
            <div className="flex items-center gap-3">
              <span className="font-serif text-2xl font-semibold tracking-wide text-cream-100">
                Prime
              </span>
              <span className="text-xs uppercase tracking-[0.3em] text-gold-400">Estate</span>
            </div>
            <nav className="hidden items-center gap-10 md:flex">
              {[
                { label: 'Характеристики', href: '#characteristics' },
                { label: 'Интерьер', href: '#interior' },
                { label: 'Галерея', href: '#gallery' },
                { label: 'Контакты', href: '#contact' },
              ].map((item) => (
                <a
                  key={item.href}
                  href={item.href}
                  className="text-sm font-medium tracking-wide text-cream-200/70 transition-colors duration-300 hover:text-gold-400"
                >
                  {item.label}
                </a>
              ))}
            </nav>
            <a
              href="#contact"
              className="rounded-sm border border-gold-500/40 px-6 py-2.5 text-xs font-medium uppercase tracking-widest text-gold-400 transition-all duration-300 hover:border-gold-400 hover:bg-gold-500/10 hover:text-gold-400"
            >
              Записаться на просмотр
            </a>
          </div>
        </div>

        {/* Hero text */}
        <div className="mx-auto flex w-full max-w-7xl flex-1 flex-col justify-center px-6 pt-32 md:px-10">
          <div className="max-w-3xl">
            <div className="mb-8 flex items-center gap-3 opacity-0" style={{ animation: 'fadeIn 1s ease 0.3s forwards' }}>
              <span className="luxury-line w-16" />
              <span className="text-xs font-medium uppercase tracking-[0.4em] text-gold-400">
                Эксклюзивное предложение
              </span>
            </div>

            <h1
              className="font-serif text-5xl font-light leading-[1.1] text-cream-50 sm:text-6xl md:text-7xl lg:text-8xl"
              style={{ animation: 'fadeIn 1.2s ease 0.5s forwards', opacity: 0 }}
            >
              Премиальный
              <br />
              <span className="gold-text font-medium">особняк</span> класса
              <br />
              де-люкс
            </h1>

            <p
              className="mt-8 max-w-xl text-lg font-light leading-relaxed text-cream-200/80"
              style={{ animation: 'fadeIn 1s ease 0.8s forwards', opacity: 0 }}
            >
              Кирпичный трёхэтажный дом в закрытом охраняемом посёлке
              «Новые Вешки». Дизайнерский ремонт под ключ, панорамные окна,
              премиальная техника и мебель.
            </p>

            {/* Price + location */}
            <div
              className="mt-12 flex flex-col gap-8 sm:flex-row sm:items-end sm:gap-12"
              style={{ animation: 'fadeIn 1s ease 1s forwards', opacity: 0 }}
            >
              <div>
                <div className="mb-2 text-xs uppercase tracking-[0.3em] text-cream-300/50">
                  Стоимость
                </div>
                <div className="font-serif text-4xl font-medium text-cream-50 sm:text-5xl">
                  <span className="gold-text">140 000 000</span>
                  <span className="ml-3 text-2xl font-light text-cream-300">₽</span>
                </div>
              </div>
              <div className="hidden h-16 w-px bg-gold-500/30 sm:block" />
              <div>
                <div className="mb-2 flex items-center gap-2 text-xs uppercase tracking-[0.3em] text-cream-300/50">
                  <MapPin className="h-3 w-3 text-gold-400" />
                  Локация
                </div>
                <div className="text-lg font-light text-cream-100">
                  Мытищи, «Новые Вешки»
                </div>
                <div className="text-sm font-light text-cream-200/60">
                  ул. Ясеневая, 34 · 2 км от МКАД
                </div>
              </div>
            </div>

            {/* Quick features */}
            <div
              className="mt-12 flex flex-wrap gap-8"
              style={{ animation: 'fadeIn 1s ease 1.2s forwards', opacity: 0 }}
            >
              {[
                { icon: Building2, label: '280 кв.м · 3 этажа' },
                { icon: Shield, label: 'Охраняемый посёлок' },
              ].map((item) => (
                <div key={item.label} className="flex items-center gap-3">
                  <item.icon className="h-5 w-5 text-gold-400" />
                  <span className="text-sm font-light text-cream-200/70">
                    {item.label}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Scroll indicator */}
        <div className="relative z-10 flex justify-center pb-10">
          <a
            href="#characteristics"
            className="flex flex-col items-center gap-2 text-cream-300/40 transition-colors duration-300 hover:text-gold-400"
          >
            <span className="text-[10px] uppercase tracking-[0.3em]">Листайте вниз</span>
            <ArrowDown className="h-4 w-4 animate-bounce" />
          </a>
        </div>
      </div>

      <style>{`
        @keyframes fadeIn {
          to { opacity: 1; }
        }
      `}</style>
    </section>
  );
}
