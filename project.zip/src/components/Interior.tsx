import { Sofa, Utensils, Eye, Zap, ShieldCheck, Crown } from 'lucide-react';
import { useScrollReveal } from '@/hooks/useScrollReveal';

const features = [
  {
    icon: Crown,
    title: 'Дизайнерский ремонт под ключ',
    text: 'Каждая деталь интерьера разработана профессиональным дизайнером. Использованы эксклюзивные материалы и дорогая мебель ведущих мировых брендов.',
  },
  {
    icon: Eye,
    title: 'Панорамное остекление',
    text: 'Внушительные окна от пола до потолка наполняют дом естественным светом и создают безупречный визуальный контакт с ухоженным участком.',
  },
  {
    icon: Zap,
    title: 'Премиальная техника',
    text: 'Дом укомплектован топовой бытовой техникой премиум-класса. Всё готово к эксплуатации — заезжайте и наслаждайтесь комфортом.',
  },
  {
    icon: ShieldCheck,
    title: 'Безопасность и приватность',
    text: 'Закрытый охраняемый посёлок с круглосуточным видеонаблюдением и контролем доступа. Стены из кирпича обеспечивают надёжность и тишину.',
  },
];

export function Interior() {
  const { ref, visible } = useScrollReveal<HTMLDivElement>();

  return (
    <section id="interior" className="relative bg-dark-900 py-24 md:py-32">
      <div className="mx-auto max-w-7xl px-6 md:px-10">
        <div ref={ref} className="grid grid-cols-1 gap-16 lg:grid-cols-2 lg:gap-24">
          {/* Left: image */}
          <div className={`scale-reveal ${visible ? 'scale-reveal-visible' : ''} relative`}>
            <div className="relative overflow-hidden rounded-sm">
              <img
                src="https://picsum.photos/id/17/1600/1000"
                alt="Интерьер особняка"
                className="h-full w-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-dark-950/60 to-transparent" />
            </div>
            {/* Decorative frame */}
            <div className="absolute -left-4 -top-4 h-24 w-24 border-l border-t border-gold-500/40" />
            <div className="absolute -bottom-4 -right-4 h-24 w-24 border-b border-r border-gold-500/40" />
          </div>

          {/* Right: text content */}
          <div className={`reveal ${visible ? 'reveal-visible' : ''} flex flex-col justify-center`}>
            <div className="mb-6 flex items-center gap-4">
              <span className="luxury-line w-12" />
              <span className="text-xs font-medium uppercase tracking-[0.4em] text-gold-400">
                Интерьер
              </span>
            </div>
            <h2 className="font-serif text-4xl font-light leading-tight text-cream-50 md:text-5xl">
              Пространство, где
              <br />
              <span className="gold-text font-medium">роскошь</span> в каждой детали
            </h2>
            <p className="mt-8 text-base font-light leading-relaxed text-cream-200/70">
              Первый этаж встречает вас просторной гостиной, объединённой с
              современной кухней — идеальным пространством для приёма гостей и
              семейных вечеров. На втором этаже расположены четыре уютные спальни,
              каждая со своим характером и атмосферой. Дорогая мебель,
              премиальная отделка и продуманное освещение создают ощущение
              безмятежной гармонии.
            </p>

            {/* Feature list */}
            <div className="mt-12 grid grid-cols-1 gap-8 sm:grid-cols-2">
              {features.map((feature, i) => (
                <div
                  key={feature.title}
                  className={`reveal ${visible ? 'reveal-visible' : ''}`}
                  style={{ transitionDelay: `${0.2 + i * 0.15}s` }}
                >
                  <feature.icon className="mb-4 h-7 w-7 text-gold-400" />
                  <h3 className="mb-2 font-serif text-lg font-medium text-cream-50">
                    {feature.title}
                  </h3>
                  <p className="text-sm font-light leading-relaxed text-cream-200/55">
                    {feature.text}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
