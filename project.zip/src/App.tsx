import { Hero } from '@/components/Hero';
import { Characteristics } from '@/components/Characteristics';
import { Interior } from '@/components/Interior';
import { Gallery } from '@/components/Gallery';
import { ContactForm } from '@/components/ContactForm';
import { Footer } from '@/components/Footer';

function App() {
  return (
    <div className="relative min-h-screen bg-dark-950">
      <Hero />
      <Characteristics />
      <Interior />
      <Gallery />
      <ContactForm />
      <Footer />
    </div>
  );
}

export default App;
