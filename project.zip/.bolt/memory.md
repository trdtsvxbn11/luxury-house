# Project memory

## Product intent & audience

- Vite + React project (TypeScript/JSX) intended for production-grade, fully featured web apps.
- Archive/export workflow is relevant: project may need to be zipped for handoff/distribution.

## Brand personality & voice

- Beautiful, non-cookie-cutter designs; production-worthy aesthetics expected.
- Polish and distinctiveness preferred over generic templates.

## Visual design & UX direction

- Styling via Tailwind CSS; components use JSX + Tailwind utility classes.
- Icons from `lucide-react`.
- Prefer a refined, custom visual direction; avoid default/template-like styling.

## Decisions, constraints & rationale

- Framework: Vite + React. No extra UI/theme/icon packages unless explicitly requested or unavoidable.
- Module imports use the `@/` path alias mapping to `src/` (avoid deep relative paths).
- React hooks available; functional component patterns assumed.
- Project zipping convention:
  - Include: source files, config files, database migrations.
  - Exclude: `node_modules`, `dist`, `.env` (credentials, regeneratable).
  - Recipients must run install + re-add own env settings.

## Open questions & assumptions

- No specific app domain, features, or page set has been defined yet.
- Backend/database stack assumed present due to mention of "database migration"; exact stack unknown.
- Whether zipping/archiving is a recurring need or a one-off is unclear.